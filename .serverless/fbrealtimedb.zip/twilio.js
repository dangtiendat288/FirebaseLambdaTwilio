const twilio = require("twilio");

const accountSid = "AC09ed674d29541046571e3842414b267b";
const authToken = "1eedd48471d16b92a42c8b758689512e";

module.exports = twilio(accountSid, authToken);
